<?php
/*Vettori globali dei parametri*/
$PARAMETER = array();
$MESSAGES = array();
?>