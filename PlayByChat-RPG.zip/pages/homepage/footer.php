<div class='footer'>
    <div class='d-flex justify-content-between'>
        <div><a href='index.php?page=homepage&content=login'>Accesso</a></div>
        <div><a href='index.php?page=homepage&content=information'>Ambientazione</a></div>
        <div><a href='index.php?page=homepage&content=contact'>Contatti</a></div>
    </div>
</div>