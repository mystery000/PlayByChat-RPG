<div class='contact'>
    <div class='hole'>
        <img src='imgs/bg.jpg'/>
        <div class='centered'>Webmaster: Vuoto<br>mailto:esperimento.staff@gmail.com</div>
    </div> 
</div>