<div class='information'>
    <pre class='text'>
    Ti svegli all'improvviso con il disperato bisogno di urlare , ma non emetti alcun suono .
    Non avverti nulla , come se i tuoi sensi siano anestetizzati , o per assurdo del tutto assenti .
    L'unica facoltà che sembri possedere al momento è la coscienza .
    Cerchi di ricordare dove sei e chi sei , ma i tuoi ricordi sono annebbiati .
    Provi a focalizzarti sull'ultimo dettaglio conosciuto , nel disperato tentativo di aggrapparti 
    a qualcosa di familiare , ma ti accorgi che non esiste .
    Anche sforzandoti , non ricordi niente .
    È come se non ci sia stato nulla prima di questo risveglio .
    Non riesci a muoverti .
    Sei cieco , sordo , anosmico e ageusico .
    Mentre il panico ti assale , iniziano a farsi strada due ipotesi nella tua mente , 
    spingendoti al limite della follia : sei appena morto o stai nascendo .
    
    Benvenuto nella tua nuova esistenza . 
    </pre>
</div>