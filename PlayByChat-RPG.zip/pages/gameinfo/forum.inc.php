<div>
    <div class="bg-dark text-center text-white border-top p-3 fs-4">Echi individuali</div>
    <div class="public_part text-center fs-3">
    </div>    
    <div class="bg-dark text-center text-white border-top p-3 fs-4">Echi emotivi</div>
    <div class="private_part text-center fs-3">
    </div>
</div>