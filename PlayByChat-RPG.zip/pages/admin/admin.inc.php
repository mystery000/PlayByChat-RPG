
<div>
    <div class="text-center fs-3"> Players</div>
    <table class="table table-dark table-hover border-top">
    <thead>
      <tr>
        <th>ID</th>
        <th>PlayerName</th>
        <th>Race</th>
        <th>Dreams and Memories</th>
        <th>Memories</th>
        <th>Allowed</th>
      </tr>
    </thead>
    <tbody>
        <?php 
            $sql = "SELECT * FROM characters";
            $msgs = gdrcd_query($sql, "result");
            while($msg = gdrcd_query($msgs, "fetch")) {
                echo "<tr>";
                echo "<td>{$msg['id']}</td>";
                echo "<td>{$msg['name']}</td>";
                echo "<td>{$msg['race']}</td>";
                echo "<td>{$msg['dreams']}</td>";
                echo "<td>{$msg['memories']}</td>";
                echo "<td><input type='checkbox'" . ($msg['allow']? 'checked': '') ."/></td>";
                echo "</tr>";
            }
        ?>
    </tbody>
    </table>
    <div class="text-center fs-3"> Messages From Players</div>
    <table class="table table-dark table-hover border-top">
    <thead>
      <tr>
        <th>ID</th>
        <th>PlayerName</th>
        <th class='text-center'>Message</th>
      </tr>
    </thead>
    <tbody>
        <?php 
            $sql = "SELECT * FROM admin_messages";
            $msgs = gdrcd_query($sql, "result");
            while($msg = gdrcd_query($msgs, "fetch")) {
                echo "<tr>";
                echo "<td>{$msg['id']}</td>";
                echo "<td>{$msg['sender']}</td>";
                echo "<td class='text-center'>{$msg['messages']}</td>";
                echo "</tr>";
            }
        ?>
    </tbody>
  </table>
</div>
<!-- <div class="modal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p>Modal body text goes here.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div> -->